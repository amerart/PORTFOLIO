
# 👋 Amer Musa | Contemporary Artist

Welcome to my official GitHub profile. I'm a visual artist exploring contemporary art through drawings and paintings.  
This space is where I share digital versions of my work and creative experiments.

🎨 **Portfolio Website**:  
[🔗 View My Portfolio](https://amerart.github.io/portfolio/)

📸 **Instagram**: [@musa.amer](https://instagram.com/musa.amer)  
📩 **Email**: amer.99.er@gmail.com

> “My work explores the silence of form, the movement of lines, and the voice of stillness.”

---

![Banner](https://raw.githubusercontent.com/amerart/portfolio/main/portfolio_images/2024-09-09_125446.jpg)
